/* Web Font Loader v{{version}} - (c) Adobe Systems, Google. License: Apache 2.0 */
(function(){{{source}}}());
